from django.shortcuts import render
from django.http.response import HttpResponseRedirect, HttpResponsePermanentRedirect
from django.contrib import auth
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from shop import models

# Create your views here.

@login_required(login_url='/acount_login/')
def home(req):
    AllOrderList = models.OrderList.objects.all()
    OrderCount = AllOrderList.count()
    WaitOrderCount = AllOrderList.filter(Status='one').count()
    BackOrderCount = AllOrderList.filter(Status='three').count()
    GetMoney = 0
    for i in AllOrderList:
        GetMoney += i.PayMoney
    # Allmoney =

    return render(req, 'DashBoard.html', locals())


def acount_login(req):
    email = req.POST.get('username')
    passwd = req.POST.get('password')
    check = authenticate(username=email, password=passwd)
    if check is not None:
        if check.is_active:
            login(req, check)
            return HttpResponsePermanentRedirect('/')
    else:
        return render(req, 'login.html', {'login_err': 'Wrong username or password!'})

    return render(req, 'login.html')


def login_out(req):
    auth.logout(req)

    return render(req, 'login.html')