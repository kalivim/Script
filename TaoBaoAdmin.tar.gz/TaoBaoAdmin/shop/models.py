# coding= utf8

from django.db import models
from django.contrib import admin
from django.contrib.auth.models import User
from django.db import models


# Create your models here.


class Delivery(models.Model):
    CompanyList = (
        ('0', '顺丰'),
        ('1', '圆通'),
        ('2', '中通'),
        ('2', '申通'),
        ('3', '韵达'),
        ('4', 'EMS'),
        ('5', '百世汇通'),
        ('6', '优速'),
    )
    company = models.CharField(max_length=10, default='6', choices=CompanyList, verbose_name='快递')
    number = models.CharField(max_length=30, blank=True, null=True, unique=True, verbose_name='单号')
    status = models.BooleanField(verbose_name='是否为退换货？', default=False, blank=True)
    data = models.DateField(null=True, blank=True, verbose_name='发货时间')

    def __unicode__(self):
        return self.number

    class Meta:
        verbose_name = '物流'
        verbose_name_plural = verbose_name


class Logo(models.Model):
    name = models.CharField(max_length=20, unique=True, verbose_name='品牌')

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = '品牌'
        verbose_name_plural = verbose_name


class Category(models.Model):
    """
    商品类型
    """
    name = models.CharField(max_length=10, unique=True, )

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = '商品类别'
        verbose_name_plural = verbose_name


class UserInfo(models.Model):
    """
    用户信息
    """
    name = models.CharField(max_length=10, verbose_name='收货人')
    PhoneNumber = models.CharField(max_length=11, verbose_name='联系电话', blank=True)
    Address = models.CharField(max_length=100, verbose_name='收货地址', blank=True)

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = '买家'
        verbose_name_plural = verbose_name


class Inventory(models.Model):
    """
    商品
    """
    name = models.CharField(max_length=20, unique=True, verbose_name=u'商品名称')
    price = models.FloatField(max_length=10, verbose_name='商品价格')
    category = models.ForeignKey(Category, blank=True, null=True, verbose_name='商品类别')
    logo = models.ForeignKey(Logo, verbose_name='品牌')

    # number = models.IntegerField(max_length=15, default=10000, verbose_name=u'库存数量')

    def __unicode__(self):
        return u"%s %s %s" % (self.logo, self.category.name, self.name)

    class Meta:
        verbose_name = '商品'
        verbose_name_plural = verbose_name


class UOM(models.Model):
    name = models.CharField(max_length=5, unique=True)

    def __unicode__(self):
        return self.name

    class Meta:
        verbose_name = '计量单位'
        verbose_name_plural = verbose_name


#

class BuyList(models.Model):
    """
    购买物品
    """
    name = models.ForeignKey(Inventory, max_length=20, unique=False, verbose_name='购买商品')
    much = models.FloatField(blank=True, verbose_name='购买数量')
    uom = models.ForeignKey(UOM, verbose_name='单位')
    AllMoney = models.FloatField(max_length=20, blank=True, null=True, verbose_name='总价')

    def money(self):
        return self.much * self.name.price

    Money = property(money)

    def save(self, force_insert=False, force_update=False, using=None,
             update_fields=None):
        self.AllMoney = self.Money
        super(BuyList, self).save(force_insert, force_update, using, update_fields)

    def __unicode__(self):
        return u"%s, %s, %s, %s%s/%s元" % (
            self.name.logo, self.name.category, self.name.name, self.much, self.uom.name, self.Money)

    class Meta:
        verbose_name = '购买物品'
        verbose_name_plural = verbose_name


class OrderList(models.Model):
    """
    订单
    """
    STATUS = (
        ('one', '待发货'),
        ('two', '已发货'),
        ('three', '售后'),
    )
    SerialNumber = models.CharField(max_length=20, unique=True, verbose_name='订单号', )
    BuyUser = models.ForeignKey(UserInfo, unique=False, verbose_name='收货人')
    Buy = models.ManyToManyField(BuyList, max_length=10, blank=True, verbose_name='购买清单')
    BuyCommodity = models.ForeignKey(Delivery, verbose_name='发货单号', blank=True, null=True)
    Status = models.CharField(max_length=10, verbose_name='订单状态', default='one', choices=STATUS)
    OrderData = models.DateField(verbose_name='订单时间', null=True, blank=True)
    remark = models.TextField(max_length=1000, blank=True, null=True, verbose_name='订单备注')
    PayMoney = models.FloatField(max_length=20, blank=True, null=True, verbose_name='应付')

    def Shop(self):
        List = OrderList.objects.get(SerialNumber=self.SerialNumber)
        Shop = List.Buy.all()
        payMoney = 0
        for i in range(0, len(Shop)):
            payMoney += Shop[i].AllMoney
        return payMoney

    ShopMoney = property(Shop)

    def save(self, force_insert=False, force_update=False, using=None,
             update_fields=None):

        # self.SerialNumber = self.SerialNumber
        # self.Buy = self.Buy
        # self.BuyCommodity = self.BuyCommodity
        # self.Status = self.Status
        # self.OrderData = self.OrderData
        # self.remark = self.remark
        try:
            self.PayMoney = self.ShopMoney
        except OrderList.DoesNotExist:
            pass
        super(OrderList, self).save(force_insert, force_update, using, update_fields)

    def __unicode__(self):
        return u"%s %s %s" % (self.BuyUser, self.SerialNumber, self.ShopMoney)

    class Meta:
        verbose_name = '订单信息'
        verbose_name_plural = verbose_name
